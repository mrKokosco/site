import React from 'react'; 
import styled from 'styled-components';
import familyPreview from './images/familyPreview.png'
import { ExceptionMap } from 'antd/lib/result';
const famaly =familyPreview

export const CardWrpper = styled.div`
    display: grid;    

    @media (min-width:576px) {  
        grid-template-columns: 1fr;
      }
    @media (min-width:960px) {  
        grid-template-columns: minmax(300px,794px) 180px;
      }
      
`

export const Card = styled.div`
background: #35383C;
box-shadow: 0px 8px 18px rgba(39,60,72,0.18);
border-radius: 8px;
display: grid;
p{
  color:#aaa!important;
}
.HeaderText{
  font-family: 'PFHighwaySansPro M'!important;
  color:#aaa!important;
  padding-left: 25px;
}

.ant-radio-button-wrapper-checked{
  border:0!important;
}
.ant-radio-button-wrapper{
  height: auto;
  margin: 0;
  padding: 0 15px;
  color: #AAAAAA;
  line-height: 30px;
  background: #25252500;
  border: 0px solid #25242400;
  border-top-width: 0px;
  outline:0;
}
.ant-radio-button-wrapper-checked:not(.ant-radio-button-wrapper-disabled) {
  z-index: 1;
  /* color: #aaa; */

  border-color: #fff;
  box-shadow: none;
  outline:0;
  filter: sepia(0.7);
}
.ant-radio-button-wrapper:not(:first-child)::before {
  background-color: #5d595900;   
   width: 0px;
}




@media (max-width:576px) {  
    grid-template-rows: auto auto auto;
    padding: 20px 0 20px 0;
    height: 100%;
    grid-template-columns: 97vw;
    h4{text-align: center;
    font-size:30px;
    }

    .ant-radio-group {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      color: #AAAAAA;
      font-size: 14px;
      font-variant: tabular-nums;
      line-height: 1.5;
      list-style: none;
      font-feature-settings: 'tnum', "tnum";
      display: grid;
      grid-template-columns: auto auto;
      text-align: center;
    }
  }
@media (min-width:576px) {  
  grid-template-columns: 97vw;
  grid-template-rows: auto auto auto;
  max-width: 959px;
  height: auto;
  padding: 20px 0px 20px 0px;
  grid-gap: 20px;
    h4{
        text-align: center;
    }
    .ant-radio-group {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      color: #AAAAAA;
      font-size: 14px;
      font-variant: tabular-nums;
      line-height: 1.5;
      list-style: none;
      font-feature-settings: 'tnum', "tnum";
      display: grid;
      grid-template-columns: auto auto auto;
      text-align: center;
    }
  }
  
@media (min-width:960px) {  
    grid-template-columns: 1fr;
    grid-template-rows: 55px 220px;
    max-width: 794px;
    height: 385px;
    padding: 20px 204px 0px 7px;
    h4{
        padding-left: 32px;
    }
  }
   
    
    
`
export const ImagesWrapper = styled.div`
    z-index: 1;
    position: relative;
    left: -176px;
    top: 66px;
    display:none;
    img{
        max-width: 362px;
    }
    @media (min-width:960px) {  
      display: grid;
  
    }
`

export const PreviewPic= styled.div`


@media (min-width:960px) {  
    background-color: white;
    background-color: white;
    background: linear-gradient(359.52deg,#202020 4.68%,rgba(53,56,60,0) 75%),url(${props => props.pic }) center center no-repeat;
    background-size: cover;
    height: 66%;
    width: 105%;
    box-shadow: 0px 8px 18px rgba(33, 33, 33, 0.39);
    border-radius: 15.3947px;
    display: grid;
    grid-template-columns: 267px auto;
    align-items: end;
    padding: 0 10px 11px 10px;
    div{
      cursor:pointer;
    }

  }

`

export const Container = styled.div`display: grid;
grid-template-columns: 2fr 1fr;
grid-template-rows: 1fr;
grid-auto-rows: 66px;
img{
    vertical-align: middle;
border-style: none;
width: 28%;
}
`

export const WithWho = styled.div`
display: grid;

@media (max-width:576px) {  
  
    justify-content: center;
    grid-template-columns: 1fr 1fr;
  }

@media (min-width:576px) {  
   
    grid-template-rows: 120px 1fr;
    grid-gap: 20px;
    grid-template-columns: repeat(3,minmax(146px,209px));
    justify-content: center;
  }

@media (min-width: 768px) {  
   
    grid-template-rows: 1fr;
    grid-gap: 20px;
    grid-template-columns: repeat(3, minmax(150px, 220px));
    grid-auto-rows: 1fr;
    justify-content: center;
  }
@media (min-width: 960px) {  
    
    grid-template-columns: 1fr 1fr 1fr;
    grid-template-rows: 120px 1fr;
    grid-gap: 20px;
  }

 


    div{
        text-align: center;
        
    }
    div:hover{
        

    }
    h5{
        color:#AAADB2;
        text-align: center;
    }

    img{
        vertical-align: middle;
        border-style: none;
        width: 40%;
        border-radius: 50%;
        padding-bottom: 9px;
        transition: all .3s ease;
    }
    img:hover{
        filter: sepia(70%);
        cursor:pointer
       
    }
   
}
`
export const ButtonForward = styled.div`
@media (max-width: 960px) {  
  
  text-align: center;
  justify-self: center;
  font-family: PFHighwaySansPro R;
  font-size:16px;
  width: 126px;
  height: 42px;
  background: #${props=>props.bgcolor};
  border: 0.72766px solid #${props=>props.bordercolor};
  color: #${props=>props.color};
  padding: 7px;
  border-radius: 10px;
  box-shadow: -7px 4px 15.829px rgb(32,32,33);   
  padding-top: 9px;
  cursor: pointer;
  transition: all ease .5s;
}
@media (min-width: 960px) {  
  display:none
  
}&:hover{

  text-align: center;
  justify-self: center;
  font-family: PFHighwaySansPro R;
  font-size:16px;
  width: 126px;
  height: 42px;
  background: #8BD53D;
  border: 0.72766px solid #8BD53D;
  color: #fff;
  padding: 7px;
  border-radius: 10px;
  box-shadow: -7px 4px 15.829px rgb(32,32,33);   
  padding-top: 9px;
  cursor: pointer;
}

    
`

// .blackCard{
//     

// }

// .filterType{
//     display: grid;
//     grid-template-rows: 92px 62px;
//     grid-template-columns: 1fr 1fr;
//     width: 518px;

// }