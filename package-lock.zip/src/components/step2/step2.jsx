import React, { useState, useRef } from 'react'

import { CardWrpper, ImagesWrapper, ImagesWrapperCard, Card, Container, WithWho, PreviewPic, ButtonForward } from './step2Style'
import { InputNumber } from 'antd'
import "../../antd.css";
import { ForMe, ForLovers, ForFamily, ForMan, ForCompany, ForParty, Forward } from './icon'
import { Button, Radio, Icon } from 'antd';
import familyPreview from './images/familyPreview.png'
import forManPreview from './images/forManPreview.jpg'

const textPreiew ={}



const Step2 = (props) => {
    let [preview, setPreview] = useState(familyPreview)
    let [textPreiew, settextPreiew] = useState('Открой для себя Байкал')
    let [inputValue, setInputValue] = useState(1)
    let inputEl = useRef(null);
    let onChangePreview = (text, pic) => {
        settextPreiew(text)
        setPreview(pic)
    }

    let onChangeInput1 = (e) => {        
        setInputValue(e.target.value)
    }

    return (
        <CardWrpper className='CardWrpper'>

            <Card className='Card'>
                <div>
                    <p className='HeaderText'>Как вы планируете отдохнуть?  </p>
                </div>
                <Radio.Group value={inputValue} onChange={onChangeInput1}>
                    <Radio.Button value="1">
                        <ForMe />
                        <p>Я еду один</p>
                    </Radio.Button>
                    <Radio.Button value="2">
                        <ForLovers />
                        <p>Пара</p>
                    </Radio.Button>
                    <Radio.Button value="3" onClick={() => { onChangePreview('Проведи это время с самыми близкими',familyPreview) }}>
                        <ForFamily />
                        <p>Семейный</p>
                    </Radio.Button>
                    <Radio.Button value="4" onClick={() => { onChangePreview('Отдохни как следует с друзьями', forManPreview) }}>
                        <ForMan />
                        <p>Чисто мужской</p>
                    </Radio.Button>
                    <Radio.Button value="5">
                        <ForCompany />
                        <p>Компания</p>
                    </Radio.Button>
                    <Radio.Button value="6">
                        <ForParty />
                        <p>Корпоративный</p>
                    </Radio.Button>
                </Radio.Group>

                <ButtonForward bordercolor={'EEEEEE'} color={'eeeeee'} bgcolor={'#eeeeee36'}>
                    Дальше
                </ButtonForward>
            </Card>

            <ImagesWrapper className='ImagesWrapper'>
                <PreviewPic pic={preview}>
                    <p>{textPreiew}</p>
                    <div>
                        <Forward />
                    </div>
                </PreviewPic>
            </ImagesWrapper>

        </CardWrpper>
    )
}

export default Step2
















 {/* <WithWho className='WithWho'>
                    <div>
                        <ForMe />
                        <p>Я еду один</p>
                    </div>
                    <div>
                        <ForLovers />
                        <p>Пара</p>
                    </div>
                    <div>
                        <ForFamily />
                        <p>Семейный</p>
                    </div>
                    <div onClick={() => { onChangePreview(forManPreview) }}>
                        <ForMan />
                        <p>Чисто мужской</p>
                    </div>
                    <div>
                        <ForCompany />
                        <p>Компания</p>
                    </div>
                    <div onClick={() => { onChangePreview(familyPreview) }}>
                        <ForParty />
                        <p>Корпоративный</p>
                    </div>
                </WithWho> */}