import React, { useState } from 'react';
import { Select } from 'antd';

const OPTIONS = ['Активный отдых' , 'Этника' ,'Посещение духовных мест' ,
 'Экскурсионный' ,'Круизы' , 'Оздоровительный' 
];


const ActionType =()=>{
  const [selectedItems, setSelectItems]   = useState([]);
  const filteredOptions = OPTIONS.filter(o => !selectedItems.includes(o))
  const handleChange=(selectedItems )=>{
    setSelectItems(selectedItems)

  }
    return (
        <Select
          mode="multiple"
          placeholder="Укажите активность"
          value={selectedItems}
          onChange={handleChange}
          style={{ width: '100%' }}
          notFoundContent={'А вы знаете толк в отдыхе!'}
         
          
        >
          {filteredOptions.map(item => (
            
            <Select.Option key={item} value={item}>
              {item}
            </Select.Option>
          ))}
        </Select>
      );

}

export default ActionType