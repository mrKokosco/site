import React from 'react';
import styled from 'styled-components';
import bg from './images/bg_filter.png'

export const FilterPageWrapper = styled.div`
    display: grid;
    margin-top: 74px;
    grid-template-rows: 1fr;
    grid-template-columns: 1fr;
`

export const FilterWrapper = styled.div`
    
background-color: #35383cf5;
background-image: url(${bg});
background-repeat: no-repeat;
background-size: contain;
     
    @media (max-width:576px) {      
        padding: 55px 43px 50px 43px;
        grid-template-columns: auto;
    }
    @media (min-width:576px) {   
        display: grid;   
        grid-template-columns: minmax(auto,211px) minmax(auto,200px) auto;
        grid-template-rows: auto auto;
        grid-gap: 32px;
        padding: 55px 43px 50px 43px;
        border-radius: 11px;
        background-color: #35383cf5;
        background-image: url(${bg});
        background-repeat: no-repeat;
        background-size: contain;
        
    }
    @media (min-width:720px) {   
        
        grid-template-columns: minmax(auto,300px) minmax(auto,295px) auto; 
     
    } 
    @media (min-width:992px) {   
        display: grid;  
        grid-template-columns: minmax(auto,300px) minmax(auto,295px) auto; 
        grid-template-rows: auto auto;
        padding: 55px 59px 50px 59px;
    } 
    
`

export const SeasonsWrapper = styled.div`
    display: grid;
    grid-template-columns: auto;
    grid-template-rows: 60px auto;
    max-width: 300px;
    
    @media (max-width:576px) {      
        grid-template-columns: auto;
        margin-bottom: 40px;
    }
    @media (min-width:576px) { 
        order:1;     
        grid-template-columns: auto;
    }
    @media (min-width:768px) {      
        grid-template-columns: auto;
    } 
    h4{
        color:#EEEEEE;
    }

    // div{
    //     display: grid;
    //     grid-template-columns: 1fr 1fr;
    //     grid-template-rows: 1fr 1fr;
    // }
    .ant-checkbox-group{
        display: grid;
        grid-template-columns: repeat(auto-fill,minmax(37px,100px));
        grid-template-rows: auto;
        max-width: 297px;
    }


    div .ant-checkbox-inner{
        width: 23px;
        height: 23px;
        border-radius: 8px;
    }

    div .ant-checkbox-inner::after{
        transform: rotate(45deg) scale(1.2) translate(-31%, -69%);
    }

    span{
        font-size: 20px
    }
`
export const PriceWrapper = styled.div`
    display: grid;
    grid-template-rows: 60px 1fr 1fr;
    grid-template-columns: auto;
    font-family: PFHighwaySansPro R;
    font-size: 16px;
    
    @media (max-width:576px) { 
        margin-bottom: 40px;     
        .ant-slider{
            display:none;
        }
    }
    @media (min-width:576px) {      
        order:4;
        .ant-slider{
            display:none;
        }
    }
    @media (min-width:992px) {      
        order:2; 
        .ant-slider{
            display:block;
        }
    }

    h4, h5{
        color: #EEEEEE;
    }
    .ant-input-number{
        height: 39px;
        font-family: PFHighwaySansPro R;
        font-size:16px;
        width: 98px;
    }
    .ant-input-number-input-wrap{
        font-family: PFHighwaySansPro R;
        font-size:16px;
        height: 39px;
    }
    .ant-input-number-input{
        height: 39px;
        padding: 0 6px;}
    .ant-slider{
        max-width: 253px;
    }
    
`

export const ActionsWrapper = styled.div`
    display: grid;
    grid-template-rows: 60px 1fr;
    justify-self: flex-end;
    min-width: 224px;
    
    @media (max-width:576px) {      
        min-width: 190px;
        margin-bottom: 40px;
        h5{
            max-width: 186px;
        }
       
    }
    @media (min-width:576px) { 
        order:3;     
        min-width: 190px;
        h5{
            max-width: 186px;
        }
        .ant-select{
            max-width: 190px;
        }
    }
    @media (min-width:768px) {      
        min-width: 224px;
        .ant-select{
            max-width: 287px;
        }
    } 
    
    .ant-select-selection--multiple{
        min-height: 85px;

    }
    
    .ant-select-selection {
        background-color: #282a2d;
        border: 1px solid #282a2d;
        border-radius: 8px;
        padding: 11px;
    }
    .ant-select-selection:hover {
        border-color: #282a2d;
        border-right-width: 1px !important;
    }
    .ant-select-selection__choice{
        background-color: #424447;
        border: 1px solid #303031;
        border-radius: 8px
    }
    .ant-select-selection__choice__content{
        color: #AAAAAA;
    }
    ul .ant-select-dropdown{
        background-color: #282a2d!important;
    }
    .ant-select-dropdown-menu-item:hover:not(.ant-select-dropdown-menu-item-disabled) {
        background-color: #8d9096;
    }

`

export const CalendarWrapper = styled.div`
    display: grid;
    grid-template-rows: 60px auto;
    max-width: 358px;
    
    @media (max-width:576px) {      
        margin-bottom: 40px;
        grid-template-rows: auto auto;
        min-width: 183px;
    }
    @media (min-width:576px) {      
        order:2;
        grid-template-rows: auto auto;
        min-width: 183px;
    }
    @media (min-width:992px) {      
        order:4; 
    }
    .ant-calendar-range{
        background-color: #35383c!important;
    }

    h4, h5{
        color: #EEEEEE;
    }
    .react-datepicker{
        font-family: 'PFHighwaySansPro R';       
        font-size: 15px;        
        background-color: #35383cf5;
        color: #000;
        border: 0;
        border-radius: 0.3rem;
        display: inline-block;
        position: relative;
        padding: 0 10px 0 10px;
    }
    .react-datepicker div{
        font-family: 'PFHighwaySansPro R';       
        font-size: 15px; 
        font-weight: normal;
        
    }   
    .react-datepicker__day-name, .react-datepicker__day, .react-datepicker__time-name {
        color: #eee;
        display: inline-block;
        width: 1.7rem;
        line-height: 1.7rem;
        text-align: center;
        margin: 0.166rem;
    }
    .react-datepicker__header {
        text-align: center;
        background-color: #35383c;
        border-bottom: 2px solid #25272a;
        border-top-left-radius: 0.3rem;
        border-top-right-radius: 5px;
        padding-top: 8px;
        position: relative;
    }
    .react-datepicker__current-month, .react-datepicker-time__header, .react-datepicker-year-header {
        margin-top: 0;
        font-family: 'PFHighwaySansPro R';
        color: #eee;
        font-weight: bold;
        font-size: 0.944rem;
    }
    .react-datepicker__day--disabled{
        cursor: default;
        color: #8b8b8b;
    }
    .react-datepicker__day:hover{
        background-color: #282a2d;
    }
    .react-datepicker__navigation--next, .react-datepicker__navigation--previous{
        outline: 0;

    }
    .ant-input:placeholder-shown {
        text-overflow: ellipsis;
        font-family: PFHighwaySansPro R;
        font-size: 16px;
    }
   
`
export const CalendarPosition = styled.div`
display: grid;

grid-gap: 10px;
grid-template-rows: auto;
@media (max-width:576px) {      
    margin-bottom: 40px;
   
}
@media (min-width:576px) {          
        grid-template-columns: auto;
    }
    @media (min-width:992px) {      
        grid-template-columns: minmax(92px,auto) minmax(92px, auto);
    }
`

export const FindButton = styled.div`
text-align: center;
    place-self: end;
    justify-self: end;
    width: 126px;
    height: 42px;
    background: rgba(238, 238, 238, 0.2);
    border: 0.72766px solid #EEEEEE;
    color: #EEEEEE;
    padding: 7px;
    border-radius: 10px;
    box-shadow: -7px 4px 15.829px rgb(32,32,33);
    grid-column-start: 3;
    display: grid;
    grid-template-columns: 1fr 35px;
    grid-template-rows: 27px;
    padding-top: 9px;
    cursor: pointer;
    
    @media (max-width:576px) {      
        margin-bottom: 40px;
       
    }
    @media (min-width:576px) {      
        order:5;
       
    }
p{
    font-size:16px!important;
}
svg{
    height: 17px;
    align-self: center;
}



`
