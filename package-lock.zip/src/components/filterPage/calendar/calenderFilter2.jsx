import React, { useState } from 'react'
import { DatePicker } from 'antd';
import moment from 'moment';
import '../../../antd.css'
import 'moment/locale/ru';



const format= "DD-MM-YYYY"
const CalenderFilter = () => {

    let [startValue, setStartValue] = useState(null)
    let [endValue, setEndValue] = useState(null)
    let [endOpen, setEndOpen] = useState(false)

    let disabledStartDate = (startVal) => {
        if (!startVal || !endValue) {
            return false;
        }
        return startVal.valueOf() > endValue.valueOf();
    }

    let disabledEndDate = endVal => {        
        if (!endVal || !startValue) {
          return false;
        }
        return endVal.valueOf() <= startValue.valueOf();
      };

    let onChange = (field, value) => {
        field(value)
    };

    let onStartChange = value => {
        onChange(setStartValue, value);
    };
    let onEndChange = value => {
        onChange(setEndValue, value);
    };

    let handleStartOpenChange = open => {
        if (!open) {
            setEndOpen(true)
        }
    };

    let handleEndOpenChange = open => {
        setEndOpen(open)
    };

    let disabledDate=(current)=> {
        // Can not select days before today and today
        return current && current < moment().endOf('day');
      }



    return (
        <>
            <DatePicker
                disabledDate={disabledStartDate}                
                format={format}
                value={startValue}
                placeholder="Начало"
                  onChange={onStartChange}
                onOpenChange={handleStartOpenChange}
                disabledDate={disabledDate}
                
            />
            <DatePicker
                  disabledDate={disabledEndDate}                
                format={format}
                value={endValue}
                placeholder="Конец"
                  onChange={onEndChange}
                open={endOpen}
              onOpenChange={handleEndOpenChange}
              disabledDate={disabledDate}
              
            />
        </>
    )
}

export default CalenderFilter