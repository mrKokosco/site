import React, { useState } from "react";
import "react-datepicker/dist/react-datepicker.css";
import { DatePicker } from 'antd';
import moment from 'moment';

// import { registerLocale, setDefaultLocale } from "react-datepicker";
// import ru_RU  from 'antd/es/locale/ru_RU';


const { MonthPicker, RangePicker } = DatePicker;

const dateFormat = 'DD-MM-YYYY';
const monthFormat = 'YYYY/MM';

const dateFormatList = ['DD-MM-YYYY', 'DD/MM/YY'];




// registerLocale('ru', ru_RU)


// CSS Modules, react-datepicker-cssmodules.css
// import 'react-datepicker/dist/react-datepicker-cssmodules.css';

const CalenderFilter = () => {
    const [startDate, setStartDate] = useState(new Date());
    
    return (
        <>
             <RangePicker className='RangePicker'
                defaultValue={[moment(new Date(), dateFormat), 
                moment(new Date(), dateFormat)]}
                format={dateFormat}
                locale="ru"
                />    
            {/* <DatePicker
                minDate={new Date()}
                selected={startDate}
                onChange={date => setStartDate(date)}
                inline
                locale="ru_RU"
            /> */}

        </>

    );
};

export default CalenderFilter