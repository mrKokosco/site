import React, { useState } from 'react';
import { Slider, InputNumber } from 'antd';
import "../../../antd.css";
import s from './priceFilter.module.css'



const PriceFilter = (props) => {
    const [price1, setPrice1] = useState(20000);
    const [price2, setPrice2] = useState(40000);
    const onChangePriceSlider = (value) => {
        setPrice1(value[0])
        setPrice2(value[1])
    }

    const onChangePriceInput1 = (value) => {
        onChangePriceSlider([value, price2])

    }

    const onChangePriceInput2 = (value) => {
        onChangePriceSlider([price1, value])

    }


    return (
       <>
           <div className={s.inputWrapper}>
                <p>от</p> <InputNumber
                    min={0}
                    max={100000}
                    style={{ marginLeft: 4 }}
                    value={props.price1}
                    onChange={props.onChangePriceInput1}
                    step={2000}
                />
                <p>до</p> <InputNumber
                    min={0}
                    max={100000}
                    style={{ marginLeft: 4 }}
                    value={props.price2}
                    onChange={props.onChangePriceInput2}
                    step={2000}
                />

            </div>

            <Slider range
                min={0}
                max={100000}
                defaultValue={[props.price1, props.price2]}
                value={[typeof props.price1 === 'number' ? props.price1 : 0, typeof props.price2 === 'number' ? props.price2 : 0]}
                onChange={props.onChangePriceSlider}
                step={2000}
                tooltipVisible={false}
                // tooltipPlacement={'bottom'}

            />

       </>
            
      

    )

}

export default PriceFilter

// import React,{useState} from 'react';
// import { Slider, InputNumber } from 'antd';
// import "antd/dist/antd.css";



// const PriceFilter = () => {
//     const [inputValue1, setinputValue1] = useState(20000);
//     const [inputValue2, setInputValue2] = useState(40000);
//     const onChange =(value)=>{
//         setinputValue1(value) 

//     }


//     return (
//         <div>
//            <Slider

//             min={0}
//             max={100000}

//             onChange={onChange}
//             value={typeof inputValue1 === 'number' ? inputValue1 : 0}

//           />
//           <Slider range defaultValue={[20, 50]} />
//           {/* <InputNumber
//             min={0}
//             max={1000000}
//             style={{ marginLeft: 16 }}

//             value={inputValue1}
//             onChange={onChange}
//             step={2000}
//           /> */}


//         </div>

//     )

// }

// export default PriceFilter