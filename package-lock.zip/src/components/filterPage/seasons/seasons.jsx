import React, { useState } from 'react';
import s from './seasons.module.css'
import { Checkbox } from 'antd';
import "../../../antd.css";
import { GridVerical } from './style';





const Saesons = (props) => {
    let [selectSeasons,setSelectSeasons]= useState(null)
    
    const options = [
        { label: 'Зима', value: 'winter' },
        { label: 'Весна', value: 'spring' },
        { label: 'Лето', value: 'summer' },
        { label: 'Осень', value: 'autumn' },
      ];
    let onChange = (value) => {
        setSelectSeasons(value)   
        props.setSeasonsType(value)
    }
   
    return (


        < >           
            <Checkbox.Group 
                options ={options} 
                defaultValue={props.seasonsType} 
                className={s.ml_8} onChange={onChange}
            />
            {/* <Checkbox onChange={onChange}>Весна</Checkbox>
            <Checkbox onChange={onChange}>Лето</Checkbox>
            <Checkbox onChange={onChange}>Осень</Checkbox> */}
            
        </>

    )

}

export default Saesons