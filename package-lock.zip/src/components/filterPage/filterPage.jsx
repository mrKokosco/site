import React from 'react';
import s from './filter.module.css'
import { Slider } from 'antd';

import Saesons from './seasons/seasons';
import PriceFilter from './priceFilter/priceFilter';
import CalendarFilter from './calendar/calenderFilter2';
import CardOfTour from './cardofTours/cardOfTour';
import { FilterPageWrapper, FilterWrapper, SeasonsWrapper, 
        PriceWrapper, ActionsWrapper, CalendarWrapper,CalendarPosition, FindButton } from './filterStyle'
import ActionType from './actions/actionsType';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSearch } from '@fortawesome/free-solid-svg-icons'



const FilterPage = (props) => {

    return (
        <FilterPageWrapper className='FilterPageWrapper'>


            <FilterWrapper className='FilterWrapper'>
                <SeasonsWrapper className='SeasonsWrapper'>
                    <h5>Время года</h5>
                    <Saesons setSeasonsType={props.setSeasonsType}
                        seasonsType={props.seasonsType}
                    />
                </SeasonsWrapper>
                <PriceWrapper className='PriceWrapper'>
                    <h5>Цена</h5>
                    <PriceFilter price1={props.price1}
                        price2={props.price2}
                        onChangePriceSlider={props.onChangePriceSlider}
                        onChangePriceInput1={props.onChangePriceInput1}
                        onChangePriceInput2={props.onChangePriceInput2}
                    />
                </PriceWrapper>
                <ActionsWrapper className='ActionsWrapper'>
                    <h5>Вид активности</h5>
                    <ActionType />
                </ActionsWrapper>
                <CalendarWrapper className='CalendarWrapper'>
                    <h5>Даты заселения</h5>
                    <CalendarPosition className='CalendarPosition'>
                         <CalendarFilter />
                    </CalendarPosition>
                  
                </CalendarWrapper>
                
                <FindButton className='FindButton'>
                    <p>Найти</p><FontAwesomeIcon className={s.color} icon={faSearch} size="lg" pull="right"/></FindButton>
            </FilterWrapper>




            <div className={s.cardsOfTours}>
                <div className={s.cadrsWrapper}>
                    <div className={s.cardsOfTours_content}>
                        <CardOfTour />
                        <CardOfTour />
                        <CardOfTour />
                        <CardOfTour />
                        <CardOfTour />
                        <CardOfTour />
                        <CardOfTour />
                    </div>
                </div>


            </div>



        </FilterPageWrapper>

    )

}

export default FilterPage