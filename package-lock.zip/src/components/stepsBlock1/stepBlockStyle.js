import React from 'react'; 
import styled from 'styled-components';


export const StepBlockWrapper = styled.div`
display: grid;
    grid-template-rows: auto auto;
    justify-content: center;
.ant-steps-item-icon{
    background-color: #fff0;
}
.ant-steps-item-finish .ant-steps-item-icon{
    background-color: #aaaaaa00;
}
.ant-steps-item-process .ant-steps-item-icon > .ant-steps-icon{
    color: #aaa;
    
}
.ant-steps-item-process .ant-steps-item-icon {   
    box-shadow: 0 0 3px rgba(34,61,74,0.22);
    background-color: #35383c;
}
.StepsWrapper{
    place-self: center;
   
    padding: 10px;
    width: auto;
}
.ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-tail::after {
    background-color: #aaa;
}
.ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-tail::after {
    background-color: #aaa;
}
.ant-steps-vertical > .ant-steps-item > .ant-steps-item-container > .ant-steps-item-tail {
    position: absolute;
    top: 0;
    left: 16px;
    width: 1px;
    height: 100%;
    padding: 29px 0 6px;
}
@media (max-width: 480px){
    .ant-steps-horizontal.ant-steps-label-horizontal .ant-steps-item {
        display: inline-block!important;
        overflow: visible;
    }
}


`

export const ContentWrapper = styled.div`
display: grid;
grid-template-rows: auto auto;
grid-gap: 30px;
 .steps-action{
    display: grid;
    grid-template-columns: auto auto;
    max-width: 288px;
}

`
export const Button = styled.div`
    text-align: center;
    
    font-family: PFHighwaySansPro R;
    font-size:16px;
    width: 126px;
    height: 42px;
    background: #${props=>props.bgcolor};
    border: 0.72766px solid #${props=>props.bordercolor};
    color: #${props=>props.color};
    padding: 7px;
    border-radius: 10px;
    box-shadow: -7px 4px 15.829px rgb(32,32,33);   
    padding-top: 9px;
    cursor: pointer;
  



`