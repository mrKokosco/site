import React, { useState } from 'react'
import {StepBlockWrapper} from './stepBlockStyle'
import { Steps, message } from 'antd';

import Step1 from '../step1/step1';
import Step2 from '../step2/step2';

const { Step } = Steps;


const StepsBlock1 = (props) => {
    let [currentStep, setCurrentStep] = useState(0)
    let onChangeStep = (current) => {
        setCurrentStep(current)
    }

    let next = () => {
        
        const current = currentStep + 1;
        setCurrentStep(current);
    }
    let prev = () => {
        
        if(currentStep > 0){
            const current = currentStep - 1;
            setCurrentStep(current);
        }
        
    }
    let onChange = current => {
        console.log('onChange:', current);
        setCurrentStep( current );
      };
    const steps = [
        {
            title: 'First',
            content: <Step1 next={next}
            setSeasonsType={props.setSeasonsType}
            seasonsType={props.seasonsType} />,
        },
        {
            title: 'Second',
            content: <Step2 next={next} />,
        }
    ];





    return (
        <>
        <StepBlockWrapper>
        <Steps className='StepsWrapper' current={currentStep} onChange={onChange}>
                <Step />
                <Step />
            </Steps>
            <div className="steps-content">{steps[currentStep].content}</div>
        </StepBlockWrapper>
           





        </>
    )
}
export default StepsBlock1