import React, { useState } from 'react'
import Seasons from '../filterPage/seasons/seasons'
import { SeasonWrapper } from '../filterPage/seasons/style'
import { Card, CardWrapper, Container, ImgWrapper, ButtonImg, ButtonForward} from './step1Style'
import { InputNumber, Select } from 'antd'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowCircleRight } from '@fortawesome/free-solid-svg-icons'
import "../../antd.css";
import { Forward } from './icon'

const { Option } = Select;

const Step1 = (props) => {

    let [inputValue, setInputValue] = useState(1)
    let onChangeInput1 = (value) => {
        props.setPeople(value)
    }

    function handleChange(value) {
        console.log(`selected ${value}`);
    }
    return (
        <Card className='Card'>
            <CardWrapper className='CardWrapper'>
                <h5>Давайте выберем вам тур всего за 3 этапа.</h5>
                <Container className='Container'>

                    <p>Когда вы хотите отдохнуть?</p>
                    <SeasonWrapper  className='SeasonWrapper'>
                        <Seasons setSeasonsType={props.setSeasonsType}
                                 seasonsType={props.seasonsType} className='Seasons' />
                    </SeasonWrapper>

                    <p>Сколько вас человек?</p>
                    <InputNumber className='InputNumber'
                        min={1}
                        max={100}
                        style={{ marginLeft: 4 }}
                        value={props.countPeople}
                        onChange={onChangeInput1}
                        step={1}
                    />



                </Container>
                <ButtonForward  onClick={props.next} bordercolor={'EEEEEE'} color={'eeeeee'} bgcolor={'#eeeeee36'}>
                            Дальше
                </ButtonForward>
            </CardWrapper>
            <ImgWrapper className='ImgWrapper'>
                <div>
                    <ButtonImg onClick={props.next} className='ButtonImg'>
                        <Forward />
                        
                    </ButtonImg>
                </div>
            </ImgWrapper>


            {/* <div><FontAwesomeIcon icon={faArrowCircleRight} size="2x" pull="right"/>

                    </div> */}



        </Card>




    )
}

export default Step1