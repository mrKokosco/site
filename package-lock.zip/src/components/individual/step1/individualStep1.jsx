import React, { useState } from 'react'
import CalenderFilter from '../../filterPage/calendar/calenderFilter2'
import ActionType from '../../filterPage/actions/actionsType'
import {StepWrapper, CalendarWrapper, CalendarPosition, ActionsWrapper } from './individualStepStyle'


const IndividualStep1 = () => {


    return (
        <>
            <StepWrapper className='StepWrapper'>
                <CalendarWrapper className='CalendarWrapper'>
                    <p>Когда в отпуск?</p>
                    <CalendarPosition className='CalendarPosition'>
                        <CalenderFilter />
                    </CalendarPosition>

                </CalendarWrapper>
                <ActionsWrapper className='ActionsWrapper'>
                <p>Вид активности</p>
                    <ActionType />
                </ActionsWrapper>
            </StepWrapper>


        </>
    )
}
export default IndividualStep1