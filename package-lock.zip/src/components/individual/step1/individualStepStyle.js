import React from 'react';
import styled from 'styled-components';


export const StepWrapper = styled.div`
    display: grid;
    grid-template-rows: auto;  
    grid-gap:42px;      
    
`

export const ActionsWrapper = styled.div`
    display: grid;
    grid-template-rows: auto auto;    
    min-width: 224px;
    max-width: 356px;
    
    p{
        color:#AAAAAA!important;
    }
    
    @media (max-width:576px) {      
       
        p{
            max-width: 186px;
        }
       
    }
    @media (min-width:576px) { 
      
        p{
            max-width: 186px;
        }
        
    }
    @media (min-width:768px) {      
        
        }
    } 
    
    .ant-select-selection--multiple{
        min-height: 85px;

    }
    
    .ant-select-selection {
        background-color: #282a2d;
        border: 1px solid #282a2d;
        border-radius: 8px;
        padding: 11px;
    }
    .ant-select-selection:hover {
        border-color: #282a2d;
        border-right-width: 1px !important;
    }
    .ant-select-selection__choice{
        background-color: #424447;
        border: 1px solid #303031;
        border-radius: 8px
    }
    .ant-select-selection__choice__content{
        color: #AAAAAA;
    }
    ul .ant-select-dropdown{
        background-color: #282a2d!important;
    }
    .ant-select-dropdown-menu-item:hover:not(.ant-select-dropdown-menu-item-disabled) {
        background-color: #8d9096;
    }
    .ant-select-selection__placeholder{
        color:#aaa;
        font-family: PFHighwaySansPro R;
        font-size:16px;
    }

`

export const CalendarWrapper = styled.div`
    display: grid;
    grid-template-rows: auto auto;
    max-width: 358px;
    p{
        color:#AAAAAA!important;
    }
    
    @media (max-width:576px) {      
        
    }
    @media (min-width:576px) {      
       
    }
    @media (min-width:992px) {      
        
    }
    .ant-calendar-range{
        background-color: #35383c!important;
    }

    h4, h5{
        color: #EEEEEE;
    }
  
   
`
export const CalendarPosition = styled.div`
    display: grid;
    grid-gap: 10px;
    grid-template-rows: auto;
    grid-template-columns: auto auto;
    .ant-input{
        height: 41px;
    }
   .ant-input::placeholder{
        color:#aaa;
        font-family: PFHighwaySansPro R;
        font-size:16px;
    }
@media (max-width:576px) {      
    
   
}
@media (min-width:576px) {          
       
    }
    @media (min-width:992px) {      
     
    }
`

