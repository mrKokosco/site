import React, { useState } from 'react'
import { Input } from 'antd';
import CalenderFilter from '../../filterPage/calendar/calenderFilter2'
import ActionType from '../../filterPage/actions/actionsType'
import { StepWrapper, CalendarWrapper, CalendarPosition, ContacsWrapper,InputWrapper, PriceWrapper } from './individualStepStyle'
import PriceFilter from '../../filterPage/priceFilter/priceFilter'


const IndividualStep2 = (props) => {


    return (
        <>
            <StepWrapper className='StepWrapper'>
                <PriceWrapper className='PriceWrapper'>
                    <p>Цена</p>
                    <PriceFilter className='PriceFilter_yaaaa' price1={props.price1}
                        price2={props.price2}
                        onChangePriceSlider={props.onChangePriceSlider}
                        onChangePriceInput1={props.onChangePriceInput1}
                        onChangePriceInput2={props.onChangePriceInput2}
                    />
                </PriceWrapper>
                <ContacsWrapper className='ContacsWrapper'>
                    
                    <InputWrapper className='InputWrapper'>
                        <p>Имя</p>
                        <Input size="large" placeholder="" />                       
                    </InputWrapper>
                    <InputWrapper className='InputWrapper'>
                        <p>Телeфон</p>
                        <Input size="large" placeholder="" />                      
                    </InputWrapper>
                   

                </ContacsWrapper>
            </StepWrapper>


        </>
    )
}
export default IndividualStep2