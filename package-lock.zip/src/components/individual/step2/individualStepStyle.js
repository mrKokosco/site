import React from 'react';
import styled from 'styled-components';


export const StepWrapper = styled.div`
    display: grid;
    grid-template-rows: auto;  
       
    
`

export const ContacsWrapper = styled.div`
    display: grid;
    grid-template-columns: auto auto;
    /* grid-template-rows: auto auto; */
    min-width: 224px;
    max-width: 356px;
    grid-gap: 30px;
    
    p{
        color:#AAAAAA!important;
    }
    
    @media (max-width:576px) {      
       
        p{
            max-width: 186px;
        }
       
    }
    @media (min-width:576px) { 
      
        p{
            max-width: 186px;
        }
        
    }
    @media (min-width:768px) {      
        
        }
    } 

`

export const PriceWrapper = styled.div`
    display: grid;
    grid-template-rows: auto 1fr 1fr;
    grid-template-columns: auto;
    font-family: PFHighwaySansPro R;
    font-size: 16px;
    max-width: 262px;
    p, div{
        color: #aaa!important;
    }
    
    
    @media (max-width:576px) { 
        margin-bottom: 40px;     
        .ant-slider{
            display:none;
        }
    }
    @media (min-width:576px) {      
         > div{
            display: grid;
            grid-template-columns: auto auto auto auto!important;
            height: 50px;
            align-items: baseline;
          }
        .ant-slider{
            
        }
    }
    @media (min-width:992px) {      
        
        .ant-slider{
            
        }
    }

    h4, h5{
        color: #EEEEEE;
    }
    .ant-input-number{
        height: 39px;
        font-family: PFHighwaySansPro R;
        font-size:16px;
        width: 98px;
    }
    .ant-input-number-input-wrap{
        font-family: PFHighwaySansPro R;
        font-size:16px;
        height: 39px;
    }
    .ant-input-number-input{
        height: 39px;
        padding: 0 6px;}
    .ant-slider{
        max-width: 253px;
    }
    
`

export const InputWrapper = styled.div`
    display: grid;
    grid-template-rows: auto auto;
    
    p{
        color:#AAAAAA!important;
    }
    
    @media (max-width:576px) {      
       
        p{
            max-width: 186px;
        }
       
    }
    @media (min-width:576px) { 
      
        p{
            max-width: 186px;
        }
        
    }
    @media (min-width:768px) {      
        
        }
    } 

`