import React from 'react'; 
import styled from 'styled-components';
import bg from './images/Winter.png';

export const IndividualWrapper = styled.div`
display: grid;
background: linear-gradient(90deg,#35383C 66%,#35383c73 ),url(${bg}) no-repeat bottom;
grid-template-columns: auto auto;
max-width: 805px;
min-height: 380px;
border-radius: 8px;
padding: 40px 25px 35px 35px;
grid-gap: 20px;
.ant-steps-item-icon{
    background-color: #fff0;
}
.ant-steps-item-finish .ant-steps-item-icon{
    background-color: #aaaaaa6b;
}
.ant-steps-item-process .ant-steps-item-icon > .ant-steps-icon{
    color: #aaa;
    
}
.ant-steps-item-process .ant-steps-item-icon {   
    box-shadow: 0px 3.36523px 8px rgba(34, 61, 74, 0.22);
}
.StepsWrapper{
    place-self: center;
}
.ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-tail::after {
    background-color: #aaa;
}
.ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-tail::after {
    background-color: #aaa;
}
.ant-steps-vertical > .ant-steps-item > .ant-steps-item-container > .ant-steps-item-tail {
    position: absolute;
    top: 0;
    left: 16px;
    width: 1px;
    height: 100%;
    padding: 29px 0 6px;
}
`

export const ContentWrapper = styled.div`
display: grid;
grid-template-rows: auto auto;
grid-gap: 30px;
 .steps-action{
    display: grid;
    grid-template-columns: auto auto;
    max-width: 288px;
}

`
export const Button = styled.div`
    text-align: center;
    
    font-family: PFHighwaySansPro R;
    font-size:16px;
    width: 126px;
    height: 42px;
    background: #${props=>props.bgcolor};
    border: 0.72766px solid #${props=>props.bordercolor};
    color: #${props=>props.color};
    padding: 7px;
    border-radius: 10px;
    box-shadow: -7px 4px 15.829px rgb(32,32,33);   
    padding-top: 9px;
    cursor: pointer;
  



`