import React, { useState } from 'react'
import { IndividualWrapper, ContentWrapper, Button } from './individualStyle'
import { Steps, message } from 'antd';
import IndividualStep1 from './step1/individualStep1';
import IndividualStep2 from './step2/individualStep2';

const { Step } = Steps;


const IndivdualTour = (props) => {
    
    const steps = [
        {
            title: 'First',
            content: <IndividualStep1/>,
        },
        {
            title: 'Second',
            content: <IndividualStep2  price1={props.price1}
            price2={props.price2}
            onChangePriceSlider={props.onChangePriceSlider}
            onChangePriceInput1={props.onChangePriceInput1}
            onChangePriceInput2={props.onChangePriceInput2}/>,
        }
    ];

    let [currentStep, setCurrentStep] = useState(0)
    let onChangeStep = (current) => {
        setCurrentStep(current)
    }

    let next = () => {
        const current = currentStep + 1;
        setCurrentStep(current);
    }
    let prev = () => {
        const current = currentStep - 1;
        setCurrentStep(current);
    }

    return (
        <>
            <IndividualWrapper className='IndividualWrapper'>
                <ContentWrapper className='ContentWrapper'>
                    <div className="steps-content">{steps[currentStep].content}</div>
                    
                    
                    <div className="steps-action">
                        {currentStep < steps.length - 1 && (
                            <Button bordercolor={'EEEEEE'} color={'eeeeee'} bgcolor={'#eeeeee36'} onClick={() => next()}>
                                Дальше
                            </Button>
                        )}
                        {currentStep === steps.length - 1 && (
                            <Button bordercolor={'8BD53D'} color={'fff'} bgcolor={'8BD53D'} onClick={() => message.success('Processing complete!')}>
                                Отправить
                            </Button>
                        )}
                        {currentStep > 0 && (
                            <Button bordercolor={'EEEEEE'} color={'eeeeee'} bgcolor={'#eeeeee36'} style={{ marginLeft: 8 }} onClick={() => prev()}>
                                Назад
                            </Button>
                        )}
                    </div>
               
                </ContentWrapper>

                <Steps className='StepsWrapper' current={currentStep} direction="vertical">
                    {steps.map(item => (
                        <Step key={item.title} />
                    ))}
                </Steps>


            </IndividualWrapper>
        </>
    )
}
export default IndivdualTour