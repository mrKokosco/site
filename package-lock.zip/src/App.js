import React,{useState} from 'react';
import logo from './logo.svg';
import './App.css';
import FilterPage from './components/filterPage/filterPage'
import IndivdualTour from './components/individual/individual'
import Step1 from './components/step1/step1';
import Step2 from './components/step2/step2';
import StepsBlock1 from './components/stepsBlock1/stepsBlock1';



function App() {
  
  let [seasonsType, setSeasonsType] = useState(null)
  let [countPeople, setCountPeople] = useState(1)
  let [withWho, setWithWho] = useState(null)
  let [price1, setPrice1] = useState(20000);
  let [price2, setPrice2] = useState(40000);

  const onChangePriceSlider = (value) => {
      setPrice1(value[0])
      setPrice2(value[1])
  }

  const onChangePriceInput1 = (value) => {
      onChangePriceSlider([value, price2])
  }

  const onChangePriceInput2 = (value) => {
      onChangePriceSlider([price1, value])
  } 

  let selectSeasons = (value) => {
    setSeasonsType(value)
  }
  let setPeople = (value) => {
      setCountPeople(value)
  }
  let selectWithWho = (value) => {
    setWithWho(value)
}



  return (
    <div className="ContainerWrapper">
     <FilterPage setSeasonsType={setSeasonsType}
                 seasonsType={seasonsType}
                 price1={price1}
                 price2={price2}
                 onChangePriceSlider={onChangePriceSlider}
                 onChangePriceInput1={onChangePriceInput1}
                 onChangePriceInput2={onChangePriceInput2}/>
    {/* <IndivdualTour price1={price1}
                 price2={price2}
                 onChangePriceSlider={onChangePriceSlider}
                 onChangePriceInput1={onChangePriceInput1}
                 onChangePriceInput2={onChangePriceInput2}/>       */}
        {/* <Step1 setSeasonsType={setSeasonsType}
                 seasonsType={seasonsType}/> */}
            {/* <Step2/> */}
            {/* <StepsBlock1 setSeasonsType={setSeasonsType}
                 seasonsType={seasonsType}/> */}
             {/* <Step2/> */}
                
    </div>


  );
}

export default App;
